use std::io;
use std::sync::{Arc, RwLock};
use std::collections::HashMap;
use super::page::{Page, PageManager};
use bincode::{serialize, deserialize};

#[derive(Serialize, Deserialize)]
pub enum LogRecord {
    Begin(u64),  // Transaction ID
    Update {
        txn_id: u64,
        page_id: u64,
        offset: u16,
        before: Vec<u8>,
        after: Vec<u8>,
    },
    Commit(u64),
    Abort(u64),
}

pub struct RecoveryManager {
    log_manager: LogManager,
    active_txns: HashMap<u64, Vec<LogRecord>>,
    page_manager: Arc<RwLock<PageManager>>,
}

impl RecoveryManager {
    pub fn new(page_manager: Arc<RwLock<PageManager>>) -> io::Result<Self> {
        Ok(RecoveryManager {
            log_manager: LogManager::new("recovery.log")?,
            active_txns: HashMap::new(),
            page_manager,
        })
    }

    pub fn begin_transaction(&mut self, txn_id: u64) -> io::Result<()> {
        let record = LogRecord::Begin(txn_id);
        self.log_manager.write_log(&record)?;
        self.active_txns.insert(txn_id, vec![record]);
        Ok(())
    }

    pub fn log_update(&mut self, 
        txn_id: u64, 
        page_id: u64, 
        offset: u16,
        before: &[u8], 
        after: &[u8]
    ) -> io::Result<()> {
        let record = LogRecord::Update {
            txn_id,
            page_id,
            offset,
            before: before.to_vec(),
            after: after.to_vec(),
        };
        
        self.log_manager.write_log(&record)?;
        if let Some(records) = self.active_txns.get_mut(&txn_id) {
            records.push(record);
        }
        Ok(())
    }

    pub fn commit(&mut self, txn_id: u64) -> io::Result<()> {
        let record = LogRecord::Commit(txn_id);
        self.log_manager.write_log(&record)?;
        self.log_manager.force()?;  // Force log to disk
        self.active_txns.remove(&txn_id);
        Ok(())
    }

    pub fn abort(&mut self, txn_id: u64) -> io::Result<()> {
        if let Some(records) = self.active_txns.remove(&txn_id) {
            // Undo changes in reverse order
            for record in records.into_iter().rev() {
                if let LogRecord::Update { page_id, offset, before, .. } = record {
                    let page = {
                        let mut manager = self.page_manager.write().unwrap();
                        manager.get_page(page_id)?
                    };
                    let mut page = page.write().unwrap();
                    page.write_data(offset as usize, &before)?;
                }
            }
            let record = LogRecord::Abort(txn_id);
            self.log_manager.write_log(&record)?;
        }
        Ok(())
    }

    pub fn recover(&mut self) -> io::Result<()> {
        // Analyze phase - scan log to find active transactions
        let (winners, losers) = self.analyze_log()?;
        
        // Redo phase - repeat history for all transactions
        self.redo_phase(&winners)?;
        
        // Undo phase - undo all loser transactions
        self.undo_phase(&losers)?;
        
        Ok(())
    }

    fn analyze_log(&self) -> io::Result<(Vec<u64>, Vec<u64>)> {
        let mut winners = Vec::new();
        let mut losers = Vec::new();
        let mut active = HashMap::new();

        for record in self.log_manager.read_log()? {
            match record {
                LogRecord::Begin(txn_id) => { active.insert(txn_id, true); }
                LogRecord::Commit(txn_id) => {
                    active.remove(&txn_id);
                    winners.push(txn_id);
                }
                LogRecord::Abort(txn_id) => {
                    active.remove(&txn_id);
                    losers.push(txn_id);
                }
                _ => {}
            }
        }

        // Any remaining active transactions are losers
        losers.extend(active.keys());
        
        Ok((winners, losers))
    }

    fn redo_phase(&mut self, winners: &[u64]) -> io::Result<()> {
        for record in self.log_manager.read_log()? {
            if let LogRecord::Update { txn_id, page_id, offset, after, .. } = record {
                if winners.contains(&txn_id) {
                    let page = {
                        let mut manager = self.page_manager.write().unwrap();
                        manager.get_page(page_id)?
                    };
                    let mut page = page.write().unwrap();
                    page.write_data(offset as usize, &after)?;
                }
            }
        }
        Ok(())
    }

    fn undo_phase(&mut self, losers: &[u64]) -> io::Result<()> {
        let mut undo_records = Vec::new();
        
        // Collect all updates from loser transactions
        for record in self.log_manager.read_log()? {
            if let LogRecord::Update { txn_id, .. } = record {
                if losers.contains(&txn_id) {
                    undo_records.push(record);
                }
            }
        }

        // Undo in reverse order
        for record in undo_records.into_iter().rev() {
            if let LogRecord::Update { txn_id, page_id, offset, before, .. } = record {
                let page = {
                    let mut manager = self.page_manager.write().unwrap();
                    manager.get_page(page_id)?
                };
                let mut page = page.write().unwrap();
                page.write_data(offset as usize, &before)?;
                
                // Write abort record
                self.log_manager.write_log(&LogRecord::Abort(txn_id))?;
            }
        }
        
        Ok(())
    }
}
