use std::collections::BTreeMap;
use std::sync::{Arc, RwLock};
use super::page::{Page, PageManager, PAGE_SIZE};

pub struct FreeSpaceMap {
    // Maps free space to pages that have that much space
    space_map: BTreeMap<u16, Vec<u64>>,
    // Maps page IDs to their free space
    page_map: BTreeMap<u64, u16>,
}

impl FreeSpaceMap {
    pub fn new() -> Self {
        FreeSpaceMap {
            space_map: BTreeMap::new(),
            page_map: BTreeMap::new(),
        }
    }

    pub fn update(&mut self, page_id: u64, free_space: u16) {
        // Remove old entry if exists
        if let Some(old_space) = self.page_map.get(&page_id) {
            if let Some(pages) = self.space_map.get_mut(old_space) {
                if let Some(pos) = pages.iter().position(|&p| p == page_id) {
                    pages.remove(pos);
                }
            }
        }

        // Add new entry
        self.page_map.insert(page_id, free_space);
        self.space_map.entry(free_space)
            .or_insert_with(Vec::new)
            .push(page_id);
    }

    pub fn find_page(&self, needed_space: u16) -> Option<u64> {
        // Find first page with enough space
        self.space_map.range(needed_space..)
            .next()
            .and_then(|(_, pages)| pages.first())
            .copied()
    }

    pub fn remove_page(&mut self, page_id: u64) {
        if let Some(free_space) = self.page_map.remove(&page_id) {
            if let Some(pages) = self.space_map.get_mut(&free_space) {
                if let Some(pos) = pages.iter().position(|&p| p == page_id) {
                    pages.remove(pos);
                }
            }
        }
    }
}
