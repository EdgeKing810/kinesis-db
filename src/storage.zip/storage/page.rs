use std::fs::{File, OpenOptions};
use std::io::{self, Read, Write, Seek, SeekFrom};
use std::sync::{Arc, RwLock};
use memmap2::{MmapMut, MmapOptions};
use lru::LruCache;
use bincode::{serialize, deserialize};

pub const PAGE_SIZE: usize = 4096;
const PAGE_HEADER_SIZE: usize = 16;
const META_PAGE_ID: u64 = 0;

#[derive(Debug)]
pub struct PageHeader {
    page_id: u64,
    page_type: u8,
    free_space: u16,
    item_count: u16,
}

impl PageHeader {
    pub fn serialize(&self) -> [u8; PAGE_HEADER_SIZE] {
        let mut bytes = [0u8; PAGE_HEADER_SIZE];
        bytes[0..8].copy_from_slice(&self.page_id.to_le_bytes());
        bytes[8] = self.page_type;
        bytes[9..11].copy_from_slice(&self.free_space.to_le_bytes());
        bytes[11..13].copy_from_slice(&self.item_count.to_le_bytes());
        bytes
    }

    pub fn deserialize(bytes: &[u8]) -> Self {
        PageHeader {
            page_id: u64::from_le_bytes(bytes[0..8].try_into().unwrap()),
            page_type: bytes[8],
            free_space: u16::from_le_bytes(bytes[9..11].try_into().unwrap()),
            item_count: u16::from_le_bytes(bytes[11..13].try_into().unwrap()),
        }
    }
}

pub struct Page {
    header: PageHeader,
    data: Vec<u8>,
    dirty: bool,
}

impl Page {
    pub fn new(page_id: u64, page_type: u8) -> Self {
        Page {
            header: PageHeader {
                page_id,
                page_type,
                free_space: (PAGE_SIZE - PAGE_HEADER_SIZE) as u16,
                item_count: 0,
            },
            data: vec![0; PAGE_SIZE - PAGE_HEADER_SIZE],
            dirty: true,
        }
    }

    pub fn write_data(&mut self, offset: usize, data: &[u8]) -> io::Result<()> {
        if offset + data.len() > self.data.len() {
            return Err(io::Error::new(io::ErrorKind::InvalidInput, "Data too large"));
        }
        self.data[offset..offset + data.len()].copy_from_slice(data);
        self.dirty = true;
        Ok(())
    }

    pub fn read_data(&self, offset: usize, len: usize) -> io::Result<&[u8]> {
        if offset + len > self.data.len() {
            return Err(io::Error::new(io::ErrorKind::InvalidInput, "Invalid read range"));
        }
        Ok(&self.data[offset..offset + len])
    }
}

pub struct PageManager {
    file: File,
    mmap: MmapMut,
    cache: LruCache<u64, Arc<RwLock<Page>>>,
    free_pages: Vec<u64>,
    next_page_id: u64,
}

impl PageManager {
    pub fn new(path: &str) -> io::Result<Self> {
        let file = OpenOptions::new()
            .read(true)
            .write(true)
            .create(true)
            .open(path)?;

        // Initialize with minimum size
        let initial_size = PAGE_SIZE as u64;
        file.set_len(initial_size)?;
        
        let mmap = unsafe { MmapOptions::new().map_mut(&file)? };
        
        let mut manager = PageManager {
            file,
            mmap,
            cache: LruCache::new(10_000),
            free_pages: Vec::new(),
            next_page_id: 1,
        };

        // Initialize metadata page if new file
        if manager.mmap.len() == PAGE_SIZE {
            let meta_page = Page::new(META_PAGE_ID, 0);
            manager.write_page(&meta_page)?;
        }

        Ok(manager)
    }

    pub fn allocate_page(&mut self) -> io::Result<u64> {
        let page_id = if let Some(free_id) = self.free_pages.pop() {
            free_id
        } else {
            let id = self.next_page_id;
            self.next_page_id += 1;
            
            // Extend file if needed
            let required_size = (id as usize + 1) * PAGE_SIZE;
            if required_size > self.mmap.len() {
                self.file.set_len(required_size as u64)?;
                self.mmap = unsafe { MmapOptions::new().map_mut(&self.file)? };
            }
            
            id
        };

        let page = Page::new(page_id, 0);
        self.write_page(&page)?;
        Ok(page_id)
    }

    pub fn get_page(&mut self, page_id: u64) -> io::Result<Arc<RwLock<Page>>> {
        if let Some(cached) = self.cache.get(&page_id) {
            return Ok(cached.clone());
        }

        let offset = page_id as usize * PAGE_SIZE;
        if offset + PAGE_SIZE > self.mmap.len() {
            return Err(io::Error::new(io::ErrorKind::NotFound, "Page not found"));
        }

        let header = PageHeader::deserialize(&self.mmap[offset..offset + PAGE_HEADER_SIZE]);
        let mut page = Page::new(page_id, header.page_type);
        page.header = header;
        page.data.copy_from_slice(&self.mmap[offset + PAGE_HEADER_SIZE..offset + PAGE_SIZE]);
        page.dirty = false;

        let page = Arc::new(RwLock::new(page));
        self.cache.put(page_id, page.clone());
        Ok(page)
    }

    pub fn write_page(&mut self, page: &Page) -> io::Result<()> {
        let offset = page.header.page_id as usize * PAGE_SIZE;
        if offset + PAGE_SIZE > self.mmap.len() {
            return Err(io::Error::new(io::ErrorKind::InvalidInput, "Invalid page ID"));
        }

        self.mmap[offset..offset + PAGE_HEADER_SIZE].copy_from_slice(&page.header.serialize());
        self.mmap[offset + PAGE_HEADER_SIZE..offset + PAGE_SIZE].copy_from_slice(&page.data);
        self.mmap.flush()?;
        Ok(())
    }

    pub fn free_page(&mut self, page_id: u64) {
        self.free_pages.push(page_id);
        self.cache.pop(&page_id);
    }
}
