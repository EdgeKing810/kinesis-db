use std::io;
use super::page::{Page, PAGE_SIZE};

const SLOT_SIZE: usize = 8;  // 8 bytes per slot (offset + length)
const HEADER_SIZE: usize = 16;  // page_id, slot_count, free_space

#[derive(Debug)]
pub struct SlottedPage {
    page_id: u64,
    slot_count: u16,
    free_space: u16,
    slots: Vec<Slot>,
    data: Vec<u8>,
}

#[derive(Debug, Clone, Copy)]
struct Slot {
    offset: u16,
    length: u16,
}

impl SlottedPage {
    pub fn new(page_id: u64) -> Self {
        SlottedPage {
            page_id,
            slot_count: 0,
            free_space: (PAGE_SIZE - HEADER_SIZE) as u16,
            slots: Vec::new(),
            data: Vec::with_capacity(PAGE_SIZE - HEADER_SIZE),
        }
    }

    pub fn insert(&mut self, data: &[u8]) -> io::Result<u16> {
        let needed_space = data.len() + SLOT_SIZE;
        if needed_space > self.free_space as usize {
            return Err(io::Error::new(io::ErrorKind::Other, "Page full"));
        }

        let slot_id = self.slot_count;
        let offset = self.data.len() as u16;
        
        // Add new slot
        self.slots.push(Slot {
            offset,
            length: data.len() as u16,
        });
        self.slot_count += 1;

        // Add data
        self.data.extend_from_slice(data);
        self.free_space -= needed_space as u16;

        Ok(slot_id)
    }

    pub fn get(&self, slot_id: u16) -> Option<&[u8]> {
        self.slots.get(slot_id as usize).map(|slot| {
            &self.data[slot.offset as usize..(slot.offset + slot.length) as usize]
        })
    }

    pub fn delete(&mut self, slot_id: u16) -> bool {
        if let Some(slot) = self.slots.get_mut(slot_id as usize) {
            self.free_space += (slot.length + SLOT_SIZE as u16) as u16;
            slot.length = 0;  // Mark as deleted
            true
        } else {
            false
        }
    }

    pub fn to_page(&self) -> Page {
        let mut page_data = Vec::with_capacity(PAGE_SIZE);
        
        // Write header
        page_data.extend_from_slice(&self.page_id.to_le_bytes());
        page_data.extend_from_slice(&self.slot_count.to_le_bytes());
        page_data.extend_from_slice(&self.free_space.to_le_bytes());

        // Write slot array
        for slot in &self.slots {
            page_data.extend_from_slice(&slot.offset.to_le_bytes());
            page_data.extend_from_slice(&slot.length.to_le_bytes());
        }

        // Write data
        page_data.extend_from_slice(&self.data);
        
        // Pad to PAGE_SIZE
        page_data.resize(PAGE_SIZE, 0);

        Page {
            id: self.page_id,
            data: page_data,
            dirty: true,
        }
    }

    pub fn from_page(page: &Page) -> Self {
        let mut slots = Vec::new();
        let page_id = u64::from_le_bytes(page.data[0..8].try_into().unwrap());
        let slot_count = u16::from_le_bytes(page.data[8..10].try_into().unwrap());
        let free_space = u16::from_le_bytes(page.data[10..12].try_into().unwrap());

        // Read slots
        let mut offset = HEADER_SIZE;
        for _ in 0..slot_count {
            let slot_offset = u16::from_le_bytes(page.data[offset..offset + 2].try_into().unwrap());
            let slot_length = u16::from_le_bytes(page.data[offset + 2..offset + 4].try_into().unwrap());
            slots.push(Slot {
                offset: slot_offset,
                length: slot_length,
            });
            offset += SLOT_SIZE;
        }

        // Extract data
        let data = page.data[offset..].to_vec();

        SlottedPage {
            page_id,
            slot_count,
            free_space,
            slots,
            data,
        }
    }
}
