use super::page::{Page, PageManager, PAGE_SIZE};
use std::io;
use std::sync::{Arc, RwLock};
use bincode::{serialize, deserialize};

const BTREE_ORDER: usize = 128;
const NODE_TYPE: u8 = 1;

#[derive(Clone, Serialize, Deserialize)]
pub struct BTreeNode {
    keys: Vec<u64>,
    values: Vec<u64>,
    children: Vec<u64>,
    leaf: bool,
}

pub struct BTree {
    root_id: u64,
    page_manager: Arc<RwLock<PageManager>>,
}

impl BTree {
    pub fn new(page_manager: Arc<RwLock<PageManager>>) -> io::Result<Self> {
        let root_id = {
            let mut manager = page_manager.write().unwrap();
            manager.allocate_page()?
        };

        let root = BTreeNode {
            keys: Vec::new(),
            values: Vec::new(),
            children: Vec::new(),
            leaf: true,
        };

        let tree = BTree {
            root_id,
            page_manager,
        };
        tree.save_node(root_id, &root)?;

        Ok(tree)
    }

    pub fn insert(&mut self, key: u64, value: u64) -> io::Result<()> {
        let root = self.load_node(self.root_id)?;
        
        if root.keys.len() >= BTREE_ORDER - 1 {
            let new_root = BTreeNode {
                keys: Vec::new(),
                values: Vec::new(),
                children: vec![self.root_id],
                leaf: false,
            };
            
            let new_root_id = {
                let mut manager = self.page_manager.write().unwrap();
                manager.allocate_page()?
            };
            
            self.save_node(new_root_id, &new_root)?;
            self.root_id = new_root_id;
            self.split_child(new_root_id, 0)?;
            self.insert_non_full(new_root_id, key, value)?;
        } else {
            self.insert_non_full(self.root_id, key, value)?;
        }

        Ok(())
    }

    fn insert_non_full(&mut self, node_id: u64, key: u64, value: u64) -> io::Result<()> {
        let mut node = self.load_node(node_id)?;
        
        if node.leaf {
            let pos = node.keys.binary_search(&key).unwrap_or_else(|p| p);
            node.keys.insert(pos, key);
            node.values.insert(pos, value);
            self.save_node(node_id, &node)?;
        } else {
            let pos = node.keys.binary_search(&key).unwrap_or_else(|p| p);
            let child_id = node.children[pos];
            let child = self.load_node(child_id)?;
            
            if child.keys.len() >= BTREE_ORDER - 1 {
                self.split_child(node_id, pos)?;
                let node = self.load_node(node_id)?;
                let pos = node.keys.binary_search(&key).unwrap_or_else(|p| p);
                self.insert_non_full(node.children[pos], key, value)?;
            } else {
                self.insert_non_full(child_id, key, value)?;
            }
        }

        Ok(())
    }

    fn split_child(&mut self, parent_id: u64, child_idx: usize) -> io::Result<()> {
        let parent = self.load_node(parent_id)?;
        let child_id = parent.children[child_idx];
        let child = self.load_node(child_id)?;

        let new_child_id = {
            let mut manager = self.page_manager.write().unwrap();
            manager.allocate_page()?
        };

        let mid = (BTREE_ORDER - 1) / 2;
        let mut new_child = BTreeNode {
            keys: child.keys[mid + 1..].to_vec(),
            values: child.values[mid + 1..].to_vec(),
            children: if (!child.leaf) { child.children[mid + 1..].to_vec() } else { Vec::new() },
            leaf: child.leaf,
        };

        let mut updated_child = BTreeNode {
            keys: child.keys[..mid].to_vec(),
            values: child.values[..mid].to_vec(),
            children: if (!child.leaf) { child.children[..mid + 1].to_vec() } else { Vec::new() },
            leaf: child.leaf,
        };

        let mut updated_parent = parent;
        updated_parent.keys.insert(child_idx, child.keys[mid]);
        updated_parent.values.insert(child_idx, child.values[mid]);
        updated_parent.children.insert(child_idx + 1, new_child_id);

        self.save_node(child_id, &updated_child)?;
        self.save_node(new_child_id, &new_child)?;
        self.save_node(parent_id, &updated_parent)?;

        Ok(())
    }

    pub fn search(&self, key: u64) -> io::Result<Option<u64>> {
        self.search_node(self.root_id, key)
    }

    fn search_node(&self, node_id: u64, key: u64) -> io::Result<Option<u64>> {
        let node = self.load_node(node_id)?;
        
        match node.keys.binary_search(&key) {
            Ok(idx) => Ok(Some(node.values[idx])),
            Err(idx) if !node.leaf => self.search_node(node.children[idx], key),
            _ => Ok(None),
        }
    }

    fn load_node(&self, node_id: u64) -> io::Result<BTreeNode> {
        let page = {
            let mut manager = self.page_manager.write().unwrap();
            manager.get_page(node_id)?
        };
        let page = page.read().unwrap();
        Ok(deserialize(&page.data).unwrap())
    }

    fn save_node(&self, node_id: u64, node: &BTreeNode) -> io::Result<()> {
        let data = serialize(node).unwrap();
        let page = {
            let mut manager = self.page_manager.write().unwrap();
            manager.get_page(node_id)?
        };
        let mut page = page.write().unwrap();
        page.write_data(0, &data)?;
        Ok(())
    }

    pub fn range_scan(&self, start_key: u64, end_key: u64) -> io::Result<Vec<(u64, u64)>> {
        let mut result = Vec::new();
        self.range_scan_node(self.root_id, start_key, end_key, &mut result)?;
        Ok(result)
    }

    fn range_scan_node(&self, node_id: u64, start_key: u64, end_key: u64, result: &mut Vec<(u64, u64)>) -> io::Result<()> {
        let node = self.load_node(node_id)?;
        
        if node.leaf {
            for (key, value) in node.keys.iter().zip(node.values.iter()) {
                if *key >= start_key && *key <= end_key {
                    result.push((*key, *value));
                }
            }
        } else {
            let mut idx = node.keys.binary_search(&start_key).unwrap_or_else(|x| x);
            if idx > 0 { idx -= 1; }

            while idx < node.children.len() {
                self.range_scan_node(node.children[idx], start_key, end_key, result)?;
                if idx < node.keys.len() && node.keys[idx] > end_key {
                    break;
                }
                idx += 1;
            }
        }
        
        Ok(())
    }

    pub fn delete(&mut self, key: u64) -> io::Result<Option<u64>> {
        let result = self.delete_key(self.root_id, key)?;
        
        // Handle empty root case
        let root = self.load_node(self.root_id)?;
        if root.keys.is_empty() && !root.leaf {
            let new_root_id = root.children[0];
            let mut manager = self.page_manager.write().unwrap();
            manager.release_page(self.root_id)?;
            self.root_id = new_root_id;
        }
        
        Ok(result)
    }

    fn delete_key(&mut self, node_id: u64, key: u64) -> io::Result<Option<u64>> {
        let mut node = self.load_node(node_id)?;
        
        match node.keys.binary_search(&key) {
            Ok(idx) if node.leaf => {
                // Found in leaf, simple removal
                let value = node.values.remove(idx);
                node.keys.remove(idx);
                self.save_node(node_id, &node)?;
                Ok(Some(value))
            }
            Ok(idx) => {
                // Found in internal node, replace with predecessor
                let value = node.values[idx];
                self.remove_internal(node_id, idx)?;
                Ok(Some(value))
            }
            Err(idx) if node.leaf => Ok(None),
            Err(idx) => {
                // Recurse to child
                self.ensure_child_size(node_id, idx)?;
                self.delete_key(node.children[idx], key)
            }
        }
    }

    fn remove_internal(&mut self, node_id: u64, key_idx: usize) -> io::Result<()> {
        // Implementation of internal node key removal
        // This is a complex operation involving finding the predecessor
        // or successor and ensuring B-tree properties are maintained
        Ok(())
    }

    fn ensure_child_size(&mut self, node_id: u64, child_idx: usize) -> io::Result<()> {
        // Ensure child has enough keys before descending
        // Implementation involves redistributing or merging nodes
        // when necessary to maintain B-tree properties
        Ok(())
    }
}
