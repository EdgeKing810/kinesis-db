use std::fs::{File, OpenOptions};
use std::io::{self, BufReader, BufWriter, Write, Read};
use bincode::{serialize, deserialize};
use super::recovery::LogRecord;

pub struct LogManager {
    file: File,
    writer: BufWriter<File>,
}

impl LogManager {
    pub fn new(path: &str) -> io::Result<Self> {
        let file = OpenOptions::new()
            .read(true)
            .write(true)
            .create(true)
            .open(path)?;
            
        let writer_file = file.try_clone()?;
        
        Ok(LogManager {
            file,
            writer: BufWriter::new(writer_file),
        })
    }

    pub fn write_log(&mut self, record: &LogRecord) -> io::Result<()> {
        let data = serialize(record).unwrap();
        let len = data.len() as u32;
        self.writer.write_all(&len.to_le_bytes())?;
        self.writer.write_all(&data)?;
        Ok(())
    }

    pub fn force(&mut self) -> io::Result<()> {
        self.writer.flush()?;
        self.file.sync_all()
    }

    pub fn read_log(&self) -> io::Result<Vec<LogRecord>> {
        let mut reader = BufReader::new(&self.file);
        let mut records = Vec::new();
        let mut buf = Vec::new();

        while let Ok(len_bytes) = reader.read_exact(&mut [0u8; 4]) {
            let len = u32::from_le_bytes(len_bytes);
            buf.resize(len as usize, 0);
            reader.read_exact(&mut buf)?;
            let record: LogRecord = deserialize(&buf).unwrap();
            records.push(record);
        }

        Ok(records)
    }
}
