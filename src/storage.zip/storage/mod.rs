use std::fs::{File, OpenOptions};
use std::io::{self, Read, Write, Seek, SeekFrom};
use std::collections::HashMap;
use std::sync::{Arc, RwLock};
use memmap2::{MmapMut, MmapOptions};
use lru::LruCache;

pub const PAGE_SIZE: usize = 4096;  // 4KB pages
const PAGE_CACHE_SIZE: usize = 10000;  // Cache 10,000 pages

pub struct Page {
    id: u64,
    data: Vec<u8>,
    dirty: bool,
}

struct PageCache {
    cache: LruCache<u64, Arc<RwLock<Page>>>,
}

pub struct PageManager {
    file: File,
    mmap: MmapMut,
    cache: PageCache,
    free_list: Vec<u64>,
    next_page_id: u64,
}

impl PageManager {
    pub fn new(path: &str) -> io::Result<Self> {
        let file = OpenOptions::new()
            .read(true)
            .write(true)
            .create(true)
            .open(path)?;
        
        // Ensure minimum file size
        file.set_len(PAGE_SIZE as u64)?;
        
        let mmap = unsafe { MmapOptions::new().map_mut(&file)? };
        
        let mut manager = PageManager {
            file,
            mmap,
            cache: PageCache { cache: LruCache::new(PAGE_CACHE_SIZE) },
            free_list: Vec::new(),
            next_page_id: 1,
        };

        manager.init_metadata()?;
        Ok(manager)
    }

    pub fn get_page(&mut self, page_id: u64) -> io::Result<Arc<RwLock<Page>>> {
        // Try cache first
        if let Some(page) = self.cache.cache.get(&page_id) {
            return Ok(page.clone());
        }

        // Read from disk
        let offset = page_id as usize * PAGE_SIZE;
        let data = self.mmap[offset..offset + PAGE_SIZE].to_vec();
        
        let page = Arc::new(RwLock::new(Page {
            id: page_id,
            data,
            dirty: false,
        }));

        self.cache.cache.put(page_id, page.clone());
        Ok(page)
    }

    pub fn write_page(&mut self, page: &Page) -> io::Result<()> {
        let offset = page.id as usize * PAGE_SIZE;
        self.mmap[offset..offset + PAGE_SIZE].copy_from_slice(&page.data);
        self.mmap.flush()?;
        Ok(())
    }

    fn init_metadata(&mut self) -> io::Result<()> {
        if self.mmap.len() == PAGE_SIZE {
            // Initialize metadata page
            let metadata = vec![
                self.next_page_id.to_le_bytes().to_vec(),
                (self.free_list.len() as u64).to_le_bytes().to_vec(),
                self.free_list.iter()
                    .flat_map(|id| id.to_le_bytes().to_vec())
                    .collect()
            ].concat();
            
            self.mmap[0..metadata.len()].copy_from_slice(&metadata);
            self.mmap.flush()?;
        } else {
            // Load existing metadata
            let next_page_id = u64::from_le_bytes(self.mmap[0..8].try_into().unwrap());
            let free_list_len = u64::from_le_bytes(self.mmap[8..16].try_into().unwrap()) as usize;
            
            self.next_page_id = next_page_id;
            self.free_list = (0..free_list_len)
                .map(|i| {
                    let start = 16 + i * 8;
                    u64::from_le_bytes(self.mmap[start..start + 8].try_into().unwrap())
                })
                .collect();
        }
        Ok(())
    }

    pub fn allocate_page(&mut self) -> io::Result<u64> {
        let page_id = self.free_list.pop().unwrap_or_else(|| {
            let id = self.next_page_id;
            self.next_page_id += 1;
            
            // Extend file if needed
            let required_size = (id as usize + 1) * PAGE_SIZE;
            if required_size > self.mmap.len() {
                self.file.set_len(required_size as u64).unwrap();
                self.mmap = unsafe { MmapOptions::new().map_mut(&self.file).unwrap() };
            }
            
            id
        });

        // Update metadata
        self.save_metadata()?;
        Ok(page_id)
    }

    fn save_metadata(&mut self) -> io::Result<()> {
        let metadata = vec![
            self.next_page_id.to_le_bytes().to_vec(),
            (self.free_list.len() as u64).to_le_bytes().to_vec(),
            self.free_list.iter()
                .flat_map(|id| id.to_le_bytes().to_vec())
                .collect()
        ].concat();
        
        self.mmap[0..metadata.len()].copy_from_slice(&metadata);
        self.mmap.flush()
    }

    pub fn release_page(&mut self, page_id: u64) -> io::Result<()> {
        self.free_list.push(page_id);
        self.cache.cache.pop(&page_id);
        self.save_metadata()
    }

    pub fn flush(&mut self) -> io::Result<()> {
        // Flush all dirty pages
        let dirty_pages: Vec<_> = self.cache.cache.iter()
            .filter(|(_, page)| page.read().unwrap().dirty)
            .map(|(id, _)| *id)
            .collect();

        for page_id in dirty_pages {
            if let Some(page) = self.cache.cache.get(&page_id) {
                let page = page.read().unwrap();
                self.write_page(&page)?;
            }
        }

        self.mmap.flush()?;
        self.file.sync_all()?;
        Ok(())
    }
}
