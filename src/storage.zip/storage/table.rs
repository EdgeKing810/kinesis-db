use std::io;
use std::sync::{Arc, RwLock};
use super::{PageManager, SlottedPage};
use super::btree::BTree;

pub struct TableMetadata {
    name: String,
    root_page: u64,
    index_root_page: u64,
    schema: Vec<ColumnDef>,
}

#[derive(Clone)]
pub struct ColumnDef {
    name: String,
    col_type: ColumnType,
    nullable: bool,
}

#[derive(Clone)]
pub enum ColumnType {
    Integer,
    Float,
    Varchar(u16),
    Boolean,
    Timestamp,
}

pub struct Table {
    metadata: TableMetadata,
    page_manager: Arc<RwLock<PageManager>>,
    index: BTree,
}

impl Table {
    pub fn new(name: String, schema: Vec<ColumnDef>, page_manager: Arc<RwLock<PageManager>>) -> io::Result<Self> {
        let root_page = page_manager.write().unwrap().allocate_page()?;
        let index_root_page = page_manager.write().unwrap().allocate_page()?;

        let metadata = TableMetadata {
            name,
            root_page,
            index_root_page,
            schema,
        };

        let index = BTree::new(page_manager.clone())?;

        Ok(Table {
            metadata,
            page_manager,
            index,
        })
    }

    pub fn insert(&mut self, record: &[u8]) -> io::Result<u64> {
        // Find a page with enough space
        let page_id = self.find_page_with_space(record.len())?;
        
        let page = {
            let mut manager = self.page_manager.write().unwrap();
            manager.get_page(page_id)?
        };

        // Insert into slotted page
        let mut slotted_page = SlottedPage::from_page(&page.read().unwrap());
        let slot_id = slotted_page.insert(record)?;

        // Update page
        let mut page = page.write().unwrap();
        *page = slotted_page.to_page();

        // Calculate record ID and update index
        let record_id = (page_id << 16) | (slot_id as u64);
        self.index.insert(record_id, page_id)?;

        Ok(record_id)
    }

    pub fn get(&self, record_id: u64) -> io::Result<Option<Vec<u8>>> {
        let page_id = record_id >> 16;
        let slot_id = (record_id & 0xFFFF) as u16;

        let page = {
            let mut manager = self.page_manager.write().unwrap();
            manager.get_page(page_id)?
        };

        let slotted_page = SlottedPage::from_page(&page.read().unwrap());
        Ok(slotted_page.get(slot_id).map(|data| data.to_vec()))
    }

    fn find_page_with_space(&self, needed_space: usize) -> io::Result<u64> {
        // Simple implementation - extend with free space map later
        let mut current_page = self.metadata.root_page;
        loop {
            let page = {
                let mut manager = self.page_manager.write().unwrap();
                manager.get_page(current_page)?
            };
            
            let slotted_page = SlottedPage::from_page(&page.read().unwrap());
            if slotted_page.free_space as usize >= needed_space {
                return Ok(current_page);
            }

            // Allocate new page if needed
            current_page = self.page_manager.write().unwrap().allocate_page()?;
        }
    }
}
