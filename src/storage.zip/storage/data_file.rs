use std::io;
use std::sync::{Arc, RwLock};
use super::PageManager;

pub struct DataFile {
    page_manager: Arc<RwLock<PageManager>>,
    free_space_map: Vec<u16>,  // Track free space in each page
}

impl DataFile {
    pub fn new(path: &str) -> io::Result<Self> {
        let page_manager = Arc::new(RwLock::new(PageManager::new(path)?));
        
        Ok(DataFile {
            page_manager,
            free_space_map: vec![PAGE_SIZE as u16],
        })
    }

    pub fn write_record(&mut self, data: &[u8]) -> io::Result<(u64, u16)> {
        // Find page with enough space
        if let Some((page_id, offset)) = self.find_space(data.len()) {
            self.write_to_page(page_id, offset, data)?;
            Ok((page_id, offset))
        } else {
            // Allocate new page
            let page_id = self.page_manager.write().unwrap().allocate_page()?.id;
            self.write_to_page(page_id, 0, data)?;
            Ok((page_id, 0))
        }
    }

    pub fn read_record(&self, page_id: u64, offset: u16, len: u16) -> io::Result<Vec<u8>> {
        let page = self.page_manager.write().unwrap().get_page(page_id)?;
        let page = page.read().unwrap();
        Ok(page.data[offset as usize..(offset + len) as usize].to_vec())
    }

    // Helper methods for space management...
}
